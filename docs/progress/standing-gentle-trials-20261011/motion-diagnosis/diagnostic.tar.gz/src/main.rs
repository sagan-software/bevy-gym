//! Passive physical diagnostic fixtures; never agent policies or qualification.
use bevy_gym::{robots::{DroidAction,DroidBody,DroidStanding},Env};
fn main() {
 for seed in [0,1,2,42,u64::MAX] {
  let mut env=DroidStanding::default();env.reset(Some(seed));
  let action=DroidAction::try_from([0.0;26]).expect("zero torque fixture");
  for step in 1..=100 {
   let state=env.step(action);
   let speeds=DroidBody::ALL.map(|body|state.observation.body(body).angular_velocity().length());
   println!("{}",serde_json::json!({"fixture":"passive-zero-torque","seed":seed,"step":step,"angular_speed_rad_s":speeds,"pelvis_height_m":state.observation.body(DroidBody::Pelvis).position().y,"done":state.status.is_done()}));
   if state.status.is_done(){break;}
  }
 }
}
